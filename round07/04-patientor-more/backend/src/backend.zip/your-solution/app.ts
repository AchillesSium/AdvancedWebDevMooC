
export { default as diagnoseRouter } from './routes-diagnoses';
export { default as patientRouter } from './routes-patients';

// ** enter commit sha of your repository in here **
export const commitSHA = '02108bd351ab35791d8395c99c416cf150679804';
