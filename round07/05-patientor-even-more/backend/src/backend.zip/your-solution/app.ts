
export { default as diagnoseRouter } from './routes-diagnoses';
export { default as patientRouter } from './routes-patients';

// ** enter commit sha of your repository in here **
export const commitSHA = '389462398ec292ffdf48b9cfdddfdc4e67207948';
